var basic_data={"Redis":{"write":56307,"read":47956},"MapDB skip list":{"write":1782680,"read":1817993},"MapDB in memory":{"write":478446,"read":1044403}};
