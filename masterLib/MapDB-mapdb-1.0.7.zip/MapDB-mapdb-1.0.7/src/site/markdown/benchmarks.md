Benchmarks
========
<script src="js/jquery-1.8.3.min.js" />
<script src="js/excanvas.js" />
<script src="js/js-class.js" />
<script src="js/bluff.js" />
<script src="js/benchmarks-data.js" />
<script src="js/benchmarks.js" />
<span id="benchmark" />

<table id="benchmarks-table">
<tr>
<th></th>
<th>Read</th>
<th>Write</th>
</tr>
</table>