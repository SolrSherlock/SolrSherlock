Performance questions
=====================

HashMap or TreeMap?
---------------------
HashMap is better suited for large keys. TreeMap is suited for smaller keys.
TreeMap may be also good choice for larger keys which can be delta-packed (strings, tuples).